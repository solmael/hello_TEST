from colorama import init, Fore
init()

def main():
    print(Fore.RED + "Hello!" + Fore.RESET)


if __name__ == '__main__':
    main()
